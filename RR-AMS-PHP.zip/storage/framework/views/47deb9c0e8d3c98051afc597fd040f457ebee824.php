<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/edits/edit-leaves.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
            <h2 class="page-title">Edit Leave</h2>
        </div>    
        </div>

        <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-content">
                <form id="edit_leave_form" action="<?php echo e(url('leaves/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                <?php echo e(csrf_field()); ?>

                    <div class="field">
                        <label>Employee</label>
                        <input type="text" class="readonly" readonly="" value="<?php if(isset($l->employee)): ?><?php echo e($l->employee); ?><?php endif; ?>">
                    </div>
                    <div class="field">
                        <label>Leave Type</label>
                        <input type="text" class="readonly" readonly="" value="<?php if(isset($l->type)): ?><?php echo e($l->type); ?><?php endif; ?>">
                    </div>
                    <div class="two fields">
                        <div class="field">
                            <label for="">Leave From</label>
                            <input type="text" class="readonly" readonly="" value="<?php if(isset($l->leavefrom)): ?><?php echo e($l->leavefrom); ?><?php endif; ?>"/>
                            
                        </div>
                        <div class="field">
                            <label for="">Leave To</label>
                            <input type="text" class="readonly" readonly="" value="<?php if(isset($l->leaveto)): ?><?php echo e($l->leaveto); ?><?php endif; ?>"/>
                        </div>
                    </div>
                    <div class="field">
                        <label for="">Return Date</label>
                        <input id="returndate" type="text" class="readonly" readonly="" value="<?php if(isset($l->returndate)): ?><?php echo e($l->returndate); ?><?php endif; ?>"/>
                    </div>
                    <div class="field">
                        <label>Reason</label>
                        <textarea class="uppercase readonly" readonly="" rows="5"><?php if(isset($l->reason)): ?><?php echo e($l->reason); ?><?php endif; ?></textarea>
                    </div>
                    <div class="field">
                        <p class="ui horizontal divider tiny sub header">Manager Privilege</p>
                    </div>
                    <div class="field">
                        <label>Status</label>
                        <select class="ui dropdown uppercase" name="status">
                            <option value="Approved" <?php if(isset($l->status)): ?> <?php if($l->status == 'Approved'): ?> selected <?php endif; ?> <?php endif; ?>>Approved</option>
                            <option value="Pending" <?php if(isset($l->status)): ?> <?php if($l->status == 'Pending'): ?> selected <?php endif; ?> <?php endif; ?>>Pending</option>
                            <option value="Declined" <?php if(isset($l->status)): ?> <?php if($l->status == 'Declined'): ?> selected <?php endif; ?> <?php endif; ?>>Declined</option>
                        </select>
                    </div>
                    <div class="field">
                        <label>Add Comment <span class="help">(OPTIONAL)</span></label>
                        <textarea name="comment" class="uppercase" rows="5"><?php if(isset($l->comment)): ?><?php echo e($l->comment); ?><?php endif; ?></textarea>
                    </div>
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"></div>
                        <ul class="list">
                            <li class=""></li>
                        </ul>
                    </div>
                </div>
                <div class="box-footer">
                    <input type="hidden" class="readonly" readonly="" name="id" value="<?php if(isset($l->id)): ?><?php echo e($l->id); ?><?php endif; ?>">
                    <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> Update</button>
                    <a href="<?php echo e(url('leaves')); ?>" class="ui black grey small button"><i class="ui times icon"></i> Cancel</a>
                </div>
                </form>
                
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>