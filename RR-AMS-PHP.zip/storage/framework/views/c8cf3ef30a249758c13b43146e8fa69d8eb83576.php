<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/users.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-add-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">Users
            <button class="ui positive button mini offsettop5 btn-add float-right"><i class="ui icon plus"></i>Add</button>
            <a href="<?php echo e(url('users/roles')); ?>" class="ui blue button mini offsettop5 float-right"><i class="ui icon user"></i>Roles</a>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php if(isset($users_roles)): ?>
                            <?php $__currentLoopData = $users_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($val->name); ?></td>
                                <td><?php echo e($val->email); ?></td>
                                <td><?php echo e($val->role_name); ?></td>
                                <td> <?php if($val->acc_type == 2): ?> Admin <?php else: ?> Employee <?php endif; ?> </td>
                                <td>
                                    <span>
                                    <?php if($val->status == '1'): ?> 
                                        Enabled
                                    <?php else: ?>
                                        Disabled
                                    <?php endif; ?>
                                    </span>
                                </td>
                                <td class="align-right">
                                    <a href="<?php echo e(url('/users/edit/'.$val->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                    <a href="<?php echo e(url('/users/delete/'.$val->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,});
    });

    $('.ui.dropdown.getemail').dropdown({ onChange: function(value, text, $selectedItem) {
        $('select[name="name"] option').each(function() {
            if($(this).val()==value) {var e = $(this).attr('data-e');var r = $(this).attr('data-ref');$('input[name="email"]').val(e);$('input[name="ref"]').val(r);};
        });
    }});
    
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>