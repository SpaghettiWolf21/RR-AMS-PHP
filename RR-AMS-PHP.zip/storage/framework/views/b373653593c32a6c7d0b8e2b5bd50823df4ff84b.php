<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/errors/permission-denied.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-6">
                <h2>Permission Denied</h2>
                <p>Sorry, you don't have permission to access the page.</p>
            </div>
        </div>

    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    

    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>