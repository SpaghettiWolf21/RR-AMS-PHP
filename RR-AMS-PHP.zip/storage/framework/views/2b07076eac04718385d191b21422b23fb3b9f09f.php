<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/fields/leave-groups.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-add-leavegroup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">Leave Groups
                <button class="ui positive mini button offsettop5 btn-add float-right"><i class="ui icon plus"></i>Add</button>
                <a href="<?php echo e(url('fields/leavetype/')); ?>" class="ui basic mini button offsettop5 float-right"><i class="icon angle left"></i>Return</a>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Leave Group</th>
                                <th>Description</th>
                                <th>Privilege</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($lg)): ?> 
                                <?php $__currentLoopData = $lg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($l->leavegroup); ?></td>
                                        <td><?php echo e($l->description); ?></td>
                                        <td>
                                            <?php if(isset($lt)): ?>
                                                <?php $__currentLoopData = $lt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <?php
                                                        $lgroup = explode(",",$l->leaveprivileges);
                                                        foreach ($lgroup as $v) {
                                                            if($v == $ln->id){
                                                                echo $ln->leavetype.", ";
                                                            }
                                                        }
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                           
                                        </td>
                                        <td><?php if($l->status == 1): ?> Active <?php else: ?> Disabled <?php endif; ?></td>
                                        <td class="align-right">
                                            <a href="<?php echo e(url('fields/leavetype/leave-groups/edit/'.$l->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                            <a href="<?php echo e(url('fields/leavetype/leave-groups/delete/'.$l->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outlin"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,});        
    });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>