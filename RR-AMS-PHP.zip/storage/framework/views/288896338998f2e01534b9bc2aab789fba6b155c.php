<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/personal/personal-update-user.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title">Update User</h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="box box-success">
                    <div class="box-content">
                       
                        <form id="edit_personal_user_form" action="<?php echo e(url('personal/update/user')); ?>" class="ui form" method="post" accept-charset="utf-8">
                        <?php echo e(csrf_field()); ?>


                        <div class="field">
                            <label>Name</label>
                            <input type="text" name="name" value="<?php if(isset($myuser->name)): ?><?php echo e($myuser->name); ?><?php endif; ?>" class="uppercase">
                        </div>

                        <div class="field">
                            <label for="">Email</label>
                            <input type="email" name="email" value="<?php if(isset($myuser->email)): ?><?php echo e($myuser->email); ?><?php endif; ?>" class="lowercase">
                        </div>

                        <div class="field">
                            <label for="">Role</label>
                            <input type="text" class="readonly uppercase" value="<?php if(isset($myrole)): ?><?php echo e($myrole); ?><?php endif; ?>" readonly=""/>
                        </div>

                        <div class="field">
                            <label for="">Status</label>
                            <input type="text" class="readonly uppercase" value="<?php if(isset($myuser->status)): ?><?php if($myuser->status == 1): ?>Enabled <?php else: ?> Disabled <?php endif; ?> <?php endif; ?>" readonly="" />
                        </div>
                        
                        <div class="field">
                            <div class="ui error message">
                            <i class="close icon"></i>
                                <div class="header"></div>
                                <ul class="list">
                                    <li class=""></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> Update</button>
                        <a class="ui grey small button" href="<?php echo e(url('personal/dashboard')); ?>"><i class="ui times icon"></i> Cancel</a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>