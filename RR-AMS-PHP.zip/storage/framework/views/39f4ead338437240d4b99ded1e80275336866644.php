<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/leaves.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">Leaves of Absence</h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>ID #</th>
                                <th>Employee</th>
                                <th>Description</th>
                                <th>Leave From</th>
                                <th>Leave To</th>
                                <th>Return Date</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($leaves)): ?>
                            <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->idno); ?></td>
                                <td><?php echo e($data->employee); ?></td>
                                <td><?php echo e($data->type); ?></td>
                                <td><?php echo e(date('D, M d, Y', strtotime($data->leavefrom))) ?></td>
                                <td><?php echo e(date('D, M d, Y', strtotime($data->leaveto))) ?></td>
                                <td><?php echo e(date('M d, Y', strtotime($data->returndate))) ?></td>
                                <td><span class=""><?php echo e($data->status); ?></span></td>
                                <td class="align-right">
                                    <a href="<?php echo e(url('leaves/edit/'.$data->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                    <a href="<?php echo e(url('leaves/delete/'.$data->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outlin"></i></a>
                                
                                    <?php if(isset($data->comment)): ?>
                                        <button class="ui circular basic icon button tiny uppercase" data-tooltip='<?php echo e($data->comment); ?>' data-variation='wide' data-position='top right'><i class="ui icon comment alternate"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,});        
    });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>