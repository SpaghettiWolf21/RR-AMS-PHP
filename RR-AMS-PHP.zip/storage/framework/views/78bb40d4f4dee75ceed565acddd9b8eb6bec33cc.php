<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/employees.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">EMPLOYEES
                <a class="ui positive button mini offsettop5 float-right" href="<?php echo e(url('employees/new')); ?>"><i class="ui icon plus"></i>Add</a>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>ID #</th> 
                            <th>Employee</th> 
                            <th>Company</th>
                            <th>Department</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th class=""></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="">
                            <td><?php echo e($employee->idno); ?></td>
                            <td><?php echo e($employee->lastname); ?>, <?php echo e($employee->firstname); ?></td>
                            <td><?php echo e($employee->company); ?></td>
                            <td><?php echo e($employee->department); ?></td>
                            <td><?php echo e($employee->jobposition); ?></td>
                            <td>
                                <?php if($employee->employmentstatus == 'Active'): ?> Active <?php else: ?> Archived <?php endif; ?>
                            </td>
                            <td class="align-right">
                            <a href="<?php echo e(url('/profile/view/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="file alternate outline icon"></i></a>
                            <a href="<?php echo e(url('/profile/edit/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="edit outline icon"></i></a>
                            <a href="<?php echo e(url('/profile/delete/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="trash alternate outline icon"></i></a>
                            <a href="<?php echo e(url('/profile/archive/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="archive icon"></i></a>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 10,lengthChange: false,searching: true,sorting: false,});
    });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>