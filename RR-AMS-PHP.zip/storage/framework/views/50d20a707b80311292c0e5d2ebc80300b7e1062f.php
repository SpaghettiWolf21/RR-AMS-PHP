<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/delete-employee.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="box box-success col-md-6">
            <div class="box-header with-border">Delete Employee Account</div>
                <div class="box-body">
                    <form action="<?php echo e(url('profile/delete/employee')); ?>" class="ui form" method="post" accept-charset="utf-8">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php if(isset($id)): ?> <?php echo e($id); ?> <?php endif; ?>">
                        <div class="field">
                            <div class="ui header" style="margin:0">Are you sure you want to delete this!</div>
                        </div>
                        <div class="field">
                            <p>Deleting this account also deletes the following data: Employee's Attendance, Schedules, Leaves, User account, or All records associated with this Employee.</p>
                        </div>
                        <div class="field">
                            <a href="<?php echo e(url('employees')); ?>" class="ui black deny button">No</a>
                            <button class="ui positive button approve" type="submit" name="submit"><i class="ui checkmark icon"></i>Yes</button>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>