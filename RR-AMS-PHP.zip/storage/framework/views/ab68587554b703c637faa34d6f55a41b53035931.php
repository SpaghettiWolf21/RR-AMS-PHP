<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/personal/personal-profile-view.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title">Profile
                    <a href="<?php echo e(url('personal/profile/edit')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon edit"></i>Edit</a>
                </h2>
            </div>    
        </div>

        <div class="row">
            <div class="col-md-4 float-left">
                <div class="box box-success">
                    <div class="box-body employee-info">
                            <div class="author">
                            <?php if($profile_photo != null): ?>
                                <img class="avatar border-white" src="<?php echo e(asset('/assets/faces/'.$profile_photo)); ?>" alt="profile photo"/>
                            <?php else: ?>
                                <img class="avatar border-white" src="<?php echo e(asset('/assets/images/faces/default_user.jpg')); ?>" alt="profile photo"/>
                            <?php endif; ?>
                            </div>
                            <p class="description text-center">
                                <h4 class="title"><?php if(isset($profile->firstname)): ?> <?php echo e($profile->firstname); ?> <?php endif; ?> <?php if(isset($profile->lastname)): ?> <?php echo e($profile->lastname); ?> <?php endif; ?></h4>
                                <table style="width: 100%" class="profile-tbl">
                                    <tbody>
                                        <tr>
                                            <td>Email</td>
                                            <td><span class="p_value"><?php if(isset($profile->emailaddress)): ?> <?php echo e($profile->emailaddress); ?> <?php endif; ?></span></td>
                                        </tr>
                                        <tr>
                                            <td>Mobile No.</td>
                                            <td><span class="p_value"><?php if(isset($profile->mobileno)): ?> <?php echo e($profile->mobileno); ?> <?php endif; ?></span></td>
                                        </tr>
                                        <tr>
                                            <td>ID No.</td>
                                            <td><span class="p_value"><?php if(isset($company_data->idno)): ?> <?php echo e($company_data->idno); ?> <?php endif; ?></span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </p>
                    </div>
                </div>
            </div>

            <div class="col-md-8 float-left">
                <div class="box box-success">
                    <div class="box-header with-border">Personal Infomation</div>
                    <div class="box-body employee-info">
                            <table class="tablelist">
                                <tbody>
                                    <tr>
                                        <td><p>Civil Status</p></td>
                                        <td><p><?php if(isset($profile->civilstatus)): ?> <?php echo e($profile->civilstatus); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Age</p></td>
                                        <td><p><?php if(isset($profile->age)): ?> <?php echo e($profile->age); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Height <span class="help">(cm)</span></p></td>
                                        <td><p><?php if(isset($profile->height)): ?> <?php echo e($profile->height); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Weight <span class="help">(pounds)</span></p></td>
                                        <td><p><?php if(isset($profile->weight)): ?> <?php echo e($profile->weight); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Gender</p></td>
                                        <td><p><?php if(isset($profile->gender)): ?> <?php echo e($profile->gender); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Date of Birth</p></td>
                                        <td><p>
                                            <?php if(isset($profile->birthday)): ?> 
                                                <?php echo e(date("F d, Y", strtotime($profile->birthday))) ?>
                                            <?php endif; ?>
                                        </p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Place of Birth</p></td>
                                        <td><p><?php if(isset($profile->birthplace)): ?> <?php echo e($profile->birthplace); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Home Address</p></td>
                                        <td><p><?php if(isset($profile->homeaddress)): ?> <?php echo e($profile->homeaddress); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>National ID</p></td>
                                        <td><p><?php if(isset($profile->nationalid)): ?> <?php echo e($profile->nationalid); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <h4 class="ui dividing header">Designation</h4>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Company</td>
                                        <td><?php if(isset($company_data->company)): ?> <?php echo e($company_data->company); ?> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td><p>Department</p></td>
                                        <td><p><?php if(isset($company_data->department)): ?> <?php echo e($company_data->department); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td>Position</td>
                                        <td><?php if(isset($company_data->jobposition)): ?> <?php echo e($company_data->jobposition); ?> <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Leave Privilege</td>
                                        <td>
                                            <?php if(isset($leavetype)): ?>
                                            <?php if(isset($leavegroup)): ?> 
                                            <?php if(isset($company_data->leaveprivilege)): ?>
                                                <?php $__currentLoopData = $leavegroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($lg->id == $company_data->leaveprivilege): ?>
                                                        <?php
                                                            $lp = explode(",", $lg->leaveprivileges);
                                                        ?>
                                                        <?php $__currentLoopData = $lp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rights): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                            <?php $__currentLoopData = $leavetype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($lt->id == $rights): ?> <?php echo e($lt->leavetype); ?>, <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><p>Employment Type</p></td>
                                        <td><p><?php if(isset($profile->employmenttype)): ?> <?php echo e($profile->employmenttype); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Employement Status</p></td>
                                        <td><p><?php if(isset($profile->employmentstatus)): ?> <?php echo e($profile->employmentstatus); ?> <?php endif; ?></p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Official Start Date</p></td>
                                        <td><p>
                                            <?php if(isset($company_data->startdate)): ?> 
                                                <?php echo e(date("F d, Y", strtotime($company_data->startdate))) ?>
                                            <?php endif; ?>
                                        </p></td>
                                    </tr>
                                    <tr>
                                        <td><p>Date Regularized</p></td>
                                        <td><p>
                                            <?php if(isset($company_data->dateregularized)): ?> 
                                                <?php echo e(date("F d, Y", strtotime($company_data->dateregularized))) ?>
                                            <?php endif; ?>
                                        </p></td>
                                    </tr>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>

        </div><!-- end of row -->
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    </script>
    <?php $__env->stopSection(); ?> 





<?php echo $__env->make('layouts.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>