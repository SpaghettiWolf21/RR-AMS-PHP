<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/auth/login.blade.php */ ?>
<!doctype html>
<!--
* Racing R Attendance Monitoring System
-->
<html lang="en" class="fullscreen-bg">

<head>
	<title>Sign in | Racing R - AMS</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
    <link href="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('/assets/css/auth.css')); ?>" rel="stylesheet">

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
				<div class="auth-box">
					<div class="content">
						<div class="header">
							<div class="logo align-center"><img src="<?php echo e(asset('/assets/images/img/Login-logo.png')); ?>" alt="Smart Timesheet"></div>
							<p class="lead">Attendance Monitoring System</p>
						</div>
						<form class="form-auth-small ui form" action="<?php echo e(route('login')); ?>" method="POST">
                       		<?php echo e(csrf_field()); ?>

							
							<div class="fields">
								<div class="sixteen wide field <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
									<label for="email" class="color-white">Email</label>
									<input id="email" type="email" class="" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your e-mail address" required autofocus>

									<?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                	<?php endif; ?>	
								</div>
							</div>
							<div class="fields">
								<div class="sixteen wide field <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
									<label for="password" class="color-white">Password</label>
                                	<input id="password" type="password" class="" name="password" placeholder="Your password" required>

                                	<?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                	<?php endif; ?>
								</div>
							</div>
							<div class="fields">
								<div class="sixteen wide field">
									<div class="ui checkbox">
										<input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
										<label class="color-white">Remember me</label>
									</div>
								</div>
							</div>

							<button type="submit" class="ui black button large fluid">SIGN IN</button>
						</form>
					</div>
				</div>
			</div>
		</div>

		
	</div>
	<!-- END WRAPPER -->

	<!--   Core JS Files   -->
    <script src="<?php echo e(asset('/assets/vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.js')); ?>"></script>
	<script>
		$('.ui.checkbox').checkbox('uncheck', 'toggle');
	</script>
</body>

</html>
