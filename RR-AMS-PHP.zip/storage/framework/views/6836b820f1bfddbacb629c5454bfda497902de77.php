<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/schedules.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <style>
        .ui.active.modal {position: relative !important;}
        .datepicker {z-index: 999 !important;}
        .datepickers-container {z-index: 9999 !important;}
    </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-add-schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">Schedules
                <button class="ui positive button mini offsettop5 btn-add float-right"><i class="ui icon plus"></i>Add</button>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 7, "desc" ]]'>
                        <thead>
                            <tr>
                                <th>ID #</th>
                                <th>Employee</th>
                                <th>Time <span class="help">(Start - Off)</span></th>
                                <th>Hours</th>
                                <th>Rest Day<span class="help">(s)</span></th>
                                <th>From <span class="help">(Date)</span></th>
                                <th>To <span class="help">(Date)</span></th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($schedules)): ?>
                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sched): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sched->idno); ?></td>
                                <td><?php echo e($sched->employee); ?></td>
                                <td><?php echo e($sched->intime); ?> - <?php echo e($sched->outime); ?></td>
                                <td><?php echo e($sched->hours); ?> hours</td>
                                <td><?php echo e($sched->restday); ?></td>
                                <td><?php echo e(date('D, M d, Y', strtotime($sched->datefrom))) ?></td>
                                <td><?php echo e(date('D, M d, Y', strtotime($sched->dateto))) ?></td>
                                <td>
                                    <?php if($sched->archive == '0'): ?> 
                                        <span class="green">Present</span>
                                    <?php else: ?>
                                        <span class="teal">Previous</span>
                                    <?php endif; ?>
                                </td>
                                <td class="align-right">
                                    <?php if($sched->archive == '0'): ?> 
                                        <a href="<?php echo e(url('/schedules/edit/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                        <a href="<?php echo e(url('/schedules/delete/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a>
                                        <a href="<?php echo e(url('/schedules/archive/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon archive"></i></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/schedules/delete/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.js')); ?>"></script>

    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,sorting: false,});
    });

    $('.jtimepicker').mdtimepicker({ format: 'h:mm:ss tt', hourPadding: true });
    $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });

    $('.ui.dropdown.getid').dropdown({ onChange: function(value, text, $selectedItem) {
        $('select[name="employee"] option').each(function() {
            if($(this).val()==value) {var id = $(this).attr('data-id');$('input[name="id"]').val(id);};
        });
    }});

    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>