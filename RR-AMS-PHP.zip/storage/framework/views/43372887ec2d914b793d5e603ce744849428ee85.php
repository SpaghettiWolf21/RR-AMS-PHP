<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/edits/edit-schedule.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
            <h2 class="page-title">Edit Schedule</h2>
        </div>    
        </div>

        <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-content">
                <form id="edit_schedule_form" action="<?php echo e(url('schedules/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                <?php echo e(csrf_field()); ?>

                    <div class="field">
                        <label>Employee</label>
                        <input type="text" value="<?php if(isset($s->employee)): ?><?php echo e($s->employee); ?><?php endif; ?>" name="employee" class="readonly" readonly="" />
                    </div>

                    <div class="two fields">
                        <div class="field">
                            <label for="">Start time</label>
                            <input type="text" placeholder="00:00:00 AM" name="intime" class="jtimepicker" value="<?php if(isset($s->intime)): ?><?php echo e($s->intime); ?><?php endif; ?>"/>
                        </div>
                        <div class="field">
                            <label for="">Off time</label>
                            <input type="text" placeholder="00:00:00 PM" name="outime" class="jtimepicker" value="<?php if(isset($s->outime)): ?><?php echo e($s->outime); ?><?php endif; ?>"/>
                        </div>
                    </div>

                    <div class="field">
                        <label for="">From</label>
                        <input type="text" placeholder="Date" name="datefrom" class="airdatepicker" value="<?php if(isset($s->datefrom)): ?><?php echo e($s->datefrom); ?><?php endif; ?>"/>
                    </div>
                    <div class="field">
                        <label for="">To</label>
                        <input type="text" placeholder="Date" name="dateto" class="airdatepicker" value="<?php if(isset($s->dateto)): ?><?php echo e($s->dateto); ?><?php endif; ?>"/>
                    </div>

                    <div class="eight wide field">
                        <label for="">Hours</label>
                        <input type="text" placeholder="0" name="hours" value="<?php if(isset($s->hours)): ?><?php echo e($s->hours); ?><?php endif; ?>"/>
                    </div>

                    <div class="grouped custom fields field">
                        <label>Rest day(s)</label>
                        <div class="field">
                        <div class="ui checkbox sunday <?php if(isset($r)): ?> <?php if(in_array('Sunday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Sunday" <?php if(isset($r)): ?> <?php if(in_array('Sunday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Sunday</label>
                        </div>
                        </div>
                        <div class="field">
                        <div class="ui checkbox <?php if(isset($r)): ?> <?php if(in_array('Monday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Monday" <?php if(isset($r)): ?> <?php if(in_array('Monday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Monday</label>
                        </div>
                        </div>
                        <div class="field">
                        <div class="ui checkbox <?php if(isset($r)): ?> <?php if(in_array('Tuesday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Tuesday" <?php if(isset($r)): ?> <?php if(in_array('Tuesday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Tuesday</label>
                        </div>
                        </div>
                        <div class="field">
                        <div class="ui checkbox <?php if(isset($r)): ?> <?php if(in_array('Wednesday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Wednesday" <?php if(isset($r)): ?> <?php if(in_array('Wednesday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Wednesday</label>
                        </div>
                        </div>
                        <div class="field">
                        <div class="ui checkbox <?php if(isset($r)): ?> <?php if(in_array('Thursday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Thursday" <?php if(isset($r)): ?> <?php if(in_array('Thursday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Thursday</label>
                        </div>
                        </div>
                        <div class="field">
                        <div class="ui checkbox <?php if(isset($r)): ?> <?php if(in_array('Friday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Friday" <?php if(isset($r)): ?> <?php if(in_array('Friday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Friday</label>
                        </div>
                        </div>
                        <div class="field">
                        <div class="ui checkbox saturday <?php if(isset($r)): ?> <?php if(in_array('Saturday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>">
                            <input type="checkbox" name="restday[]" value="Saturday" <?php if(isset($r)): ?> <?php if(in_array('Saturday', $r) == true): ?> checked <?php endif; ?> <?php endif; ?>>
                            <label>Saturday</label>
                        </div>
                        </div>
                    </div>
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"></div>
                        <ul class="list">
                            <li class=""></li>
                        </ul>
                    </div>
                </div>

                <div class="box-footer">
                    <input type="hidden" name="id" value="<?php if(isset($s->id)): ?><?php echo e($s->id); ?><?php endif; ?>">
                    <button class="ui positive approve small button" type="submit" name="submit"><i class="ui checkmark icon"></i> Update</button>
                    <a href="<?php echo e(url('schedules')); ?>" class="ui black grey small button"><i class="ui times icon"></i> Cancel</a>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#dataTables-example').DataTable({ responsive: true, pageLength: 15, lengthChange: false, });
        });

        $('.jtimepicker').mdtimepicker({ format: 'h:mm:ss tt', hourPadding: true });
        $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });
        
        $('.ui.dropdown.getid').dropdown({ onChange: function(value, text, $selectedItem) {
            $('select[name="employee"] option').each(function() {
                if($(this).val()==value) { var id = $(this).attr('data-id'); $('input[name="id"]').val(id); };
            });
        }});

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>