<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/attendance.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">Attendance
                <a href="<?php echo e(url('clock')); ?>" class="ui positive button mini offsettop5 float-right"><i class="ui icon clock"></i>Clock In/Out</a>
            </h2>
        </div>  

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>ID #</th>
                                <th>Date</th>
                                <th>Employee</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Total Hours</th>
                                <th>Status (In / Out)</th>
                                <?php if(isset($clock_comment)): ?>
                                    <?php if($clock_comment == 1): ?>
                                        <th>Comment</th>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($data)): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->idno); ?></td>
                                <td><?php echo e($d->date); ?></td>
                                <td><?php echo e($d->employee); ?></td>
                                <td><?php $IN = date('h:i:s A', strtotime($d->timein)); echo $IN; ?></td>
                                <td>
                                    <?php if(isset($d->timeout)): ?>
                                        <?php 
                                            $OUT = date('h:i:s A', strtotime($d->timeout));
                                        ?>
                                        <?php if($d->timeout != NULL): ?>
                                            <?php echo e($OUT); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td class="align-right">
                                    <?php if(isset($d->totalhours)): ?>
                                        <?php if($d->totalhours != null): ?> 
                                            <?php
                                                if(stripos($d->totalhours, ".") === false) {
                                                    $h = $d->totalhours;
                                                } else {
                                                    $HM = explode('.', $d->totalhours); 
                                                    $h = $HM[0]; 
                                                    $m = $HM[1];
                                                }
                                            ?>
                                        <?php endif; ?>
                                        <?php if($d->totalhours != null): ?>
                                            <?php if(stripos($d->totalhours, ".") === false): ?> 
                                                <?php echo e($h); ?> hr
                                            <?php else: ?> 
                                                <?php echo e($h); ?> hr <?php echo e($m); ?> minutes
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>

                                <td> <!--In and Out Status Comment!-->
                                    <?php if($d->status_timein != null OR $d->status_timeout != null): ?> 
                                        <span class="<?php if($d->status_timein == 'Late Arrival'): ?> orange <?php else: ?> blue <?php endif; ?>"><?php echo e($d->status_timein); ?></span> /
                                        
                                        <?php if(isset($d->status_timeout)): ?> 
                                            <span class="<?php if($d->status_timeout == 'Early Departure'): ?> red <?php else: ?> green <?php endif; ?>">
                                                <?php echo e($d->status_timeout); ?>

                                            </span> 
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="blue"><?php echo e($d->status_timein); ?></span>
                                    <?php endif; ?> 
                                </td>

                                <?php if(isset($clock_comment)): ?>
                                    <?php if($clock_comment == 1): ?>
                                        <td><?php echo e($d->comment); ?></td>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <td class="align-right">
                                    <a href="<?php echo e(url('/attendance/edit/'.$d->id)); ?>" class="ui circular basic icon button tiny"><i class="edit outline icon"></i></a>
                                    <a href="<?php echo e(url('/attendance/delete/'.$d->id)); ?>" class="ui circular basic icon button tiny"><i class="trash alternate outline icon"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,sorting: false,});
    });
    </script> 

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>