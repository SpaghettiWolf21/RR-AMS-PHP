<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/edits/edit-leavegroups.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
            <h2 class="page-title">Edit Leave Group</h2>
        </div>    
        </div>

        <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-content">
                <form id="edit_leavegroup_form" action="<?php echo e(url('fields/leavetype/leave-groups/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                <?php echo e(csrf_field()); ?>

                    <div class="field">
                        <label>Leave Group name</label>
                        <input type="text" name="leavegroup" value="<?php if(isset($lg)): ?><?php echo e($lg->leavegroup); ?><?php endif; ?>" class="uppercase" placeholder="Enter Leave Group Name">
                    </div>
                    <div class="field">
                        <label>Description</label>
                        <input type="text" name="description" value="<?php if(isset($lg)): ?><?php echo e($lg->description); ?><?php endif; ?>" class="uppercase" placeholder="Enter Description for Leave Group">
                    </div>
                    <div class="field">
                        <label>Leave Privileges</label>
                        <select class="ui search dropdown selection multiple leaves uppercase" name="leaveprivileges[]" multiple="">
                            <option value="">Select Leave Privileges</option>
                            <?php if(isset($lt)): ?> 
                                <?php $__currentLoopData = $lt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($leave->id); ?>"><?php echo e($leave->leavetype); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="field">
                        <label>Status</label>
                        <select class="ui dropdown uppercase" name="status">
                            <option value="">Select Status</option>
                            <option value="1" <?php if(isset($lg)): ?> <?php if($lg->status == 1): ?> selected <?php endif; ?> <?php endif; ?>>Active</option>
                            <option value="0" <?php if(isset($lg)): ?> <?php if($lg->status == 0): ?> selected <?php endif; ?> <?php endif; ?>>Disabled</option>
                        </select>
                    </div>
                    <div class="field">
                        <div class="ui error message">
                            <i class="close icon"></i>
                            <div class="header"></div>
                            <ul class="list">
                                <li class=""></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <input type="hidden" name="id" value="<?php if(isset($lg)): ?><?php echo e($lg->id); ?><?php endif; ?>">
                    <button class="ui positive approve small button" type="submit" name="submit"><i class="ui checkmark icon"></i> Update</button>
                    <a href="<?php echo e(url('fields/leavetype/leave-groups')); ?>" class="ui black grey small button"><i class="ui times icon"></i> Cancel</a>
                </div>
                </form>
                
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script>
        var selected = "<?php if(isset($lg)): ?><?php echo e($lg->leaveprivileges); ?><?php endif; ?>";
        var items = selected.split(',');
        $('.ui.dropdown.multiple.leaves').dropdown('set selected', items);
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>