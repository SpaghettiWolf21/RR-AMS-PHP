<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/layouts/default.blade.php */ ?>
<!doctype html>
<!--
* Racing R Attendance Monitoring System
-->
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

        <title>Racing R - AMS</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/bootstrap/css/bootstrap.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/DataTables/datatables.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/style.css')); ?>">
        
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="<?php echo e(asset('/assets/js/html5shiv.js')); ?>></script>
            <script src="<?php echo e(asset('/assets/js/respond.min.js')); ?>"></script>
        <![endif]-->

        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body>

        <div class="wrapper">
        
        <nav id="sidebar" class="active">
            <div class="sidebar-header bg-lightblue">
                <div class="logo">
                <a href="/" class="simple-text">
                    <img src="<?php echo e(asset('/assets/images/img/RR-logo.png')); ?>">
                </a>
                </div>
            </div>

            <ul class="list-unstyled components">
                <li class="">
                    <a href="<?php echo e(url('dashboard')); ?>">
                        <i class="ui icon sliders horizontal"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('employees')); ?>">
                        <i class="ui icon users"></i>
                        <p>Employees</p>
                    </a>
                </li>
                    
                <li class="">
                    <a href="<?php echo e(url('attendance')); ?>">
                        <i class="ui icon clock outline"></i>
                        <p>Attendances</p>
                    </a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('schedules')); ?>">
                        <i class="ui icon calendar alternate outline"></i>
                        <p>Schedules</p>
                    </a>
                </li>
                
                <li class="">
                    <a href="<?php echo e(url('leaves')); ?>">
                        <i class="ui icon calendar plus outline"></i>
                        <p>Leave</p>
                    </a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('reports')); ?>">
                        <i class="ui icon chart bar outline"></i>
                        <p>Reports</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('users')); ?>">
                        <i class="ui icon user circle outline"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('settings')); ?>">
                        <i class="ui icon cog"></i>
                        <p>Settings</p>
                    </a>
                </li>
            </ul>
        </nav>

        <div id="body" class="active">
            <nav class="navbar navbar-expand-lg navbar-light bg-lightblue">
                <div class="container-fluid">

                    <button type="button" id="slidesidebar" class="ui icon button btn-light-outline">
                        <i class="ui icon bars"></i> Menu
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto navmenu">
                            <li class="nav-item">
                                <div class="ui pointing link dropdown item" tabindex="0">
                                    <i class="ui icon th"></i> <span class="navmenutext">Quick Access</span>
                                    <i class="dropdown icon"></i>
                                    <div class="menu" tabindex="-1">
                                      <a href="<?php echo e(url('employees/new')); ?>" class="item"><i class="ui icon user plus"></i> Add Employee</a>
                                      <a href="<?php echo e(url('clock')); ?>" target="_blank" class="item"><i class="ui icon clock outline"></i> Clock In/Out</a>
                                      <div class="divider"></div>
                                      <a href="<?php echo e(url('fields/company')); ?>" class="item"><i class="ui icon university"></i> Company</a>
                                      <a href="<?php echo e(url('fields/department')); ?>" class="item"><i class="ui icon cubes"></i> Department</a>
                                      <a href="<?php echo e(url('fields/jobtitle')); ?>" class="item"><i class="ui icon pencil alternate"></i> Job Title</a>
                                      <a href="<?php echo e(url('fields/leavetype')); ?>" class="item"><i class="ui icon calendar alternate outline"></i> Leave Type</a>
                                    </div>
                              </div>
                            </li>
                            <li class="nav-item">
                               <div class="ui pointing link dropdown item" tabindex="0">
                                    <i class="ui icon user outline"></i> <span class="navmenutext"><?php if(isset(Auth::user()->name)): ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?></span>
                                    <i class="dropdown icon"></i>
                                    <div class="menu" tabindex="-1">
                                      <a href="<?php echo e(url('update-profile')); ?>" class="item"><i class="ui icon user"></i> Update User</a>
                                      <a href="<?php echo e(url('update-password')); ?>" class="item"><i class="ui icon lock"></i> Change Password</a>
                                      <a href="<?php echo e(url('personal/dashboard')); ?>" target="_blank" class="item"><i class="ui icon sign-in"></i> Switch to MyAccount</a>
                                      <div class="divider"></div>
                                      <a href="<?php echo e(url('logout')); ?>" class="item"><i class="ui icon power"></i> Logout</a>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
            </nav>

            <div class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <input type="hidden" id="_url" value="<?php echo e(url('/')); ?>">
        </div>
    </div>

    <script src="<?php echo e(asset('/assets/vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/bootstrap-notify.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/script.js')); ?>"></script>
    <?php if($success = Session::get('success')): ?>
    <script>
        $(document).ready(function() {
            $.notify({
                icon: 'ui icon check',
                message: "<?php echo e($success); ?>"},
                {type: 'success',timer: 400}
            );
        });
    </script>
    <?php endif; ?>

    <?php if($error = Session::get('error')): ?>
    <script>
        $(document).ready(function() {
            $.notify({
                icon: 'ui icon times',
                message: "<?php echo e($error); ?>"},
                {type: 'danger',timer: 400});
        });
    </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html>