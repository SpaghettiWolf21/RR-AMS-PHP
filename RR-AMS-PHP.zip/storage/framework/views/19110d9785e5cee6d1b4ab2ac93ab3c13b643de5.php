<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/edits/edit-attendance.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
            <h2 class="page-title">Edit Attendance</h2>
        </div>    
        </div>

        <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-content">
                    
                    <form id="edit_attendance_form" action="<?php echo e(url('attendance/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                    <?php echo e(csrf_field()); ?>

                    
                    <?php if($a->timeout != null): ?>
                        <div class="two fields">
                            <div class="field">
                                <label>Employee</label>
                                <input type="text" name="employee" class="readonly" readonly="" value="<?php if(isset($a->employee)): ?><?php echo e($a->employee); ?><?php endif; ?>">
                            </div>
                            <div class="field">
                                <label for="">Date</label>
                                <input class="readonly" type="text" placeholder="Date" name="date" value="<?php if(isset($a->date)): ?><?php echo e($a->date); ?><?php endif; ?>" readonly="" />
                            </div>
                        </div>
                    <?php else: ?> 
                        <div class="field">
                            <label>Employee</label>
                            <input type="text" name="employee" class="readonly" readonly="" value="<?php if(isset($a->employee)): ?><?php echo e($a->employee); ?><?php endif; ?>">
                        </div>
                    <?php endif; ?>
                    
                    <?php if($a->timeout != null): ?>
                        <div class="field">
                            <label for="">Time In</label>
                            <?php if(isset($a->timein)): ?> 
                                <?php 
                                    $t_in = date("h:i:s A",strtotime($a->timein)); 
                                    $t_in_date = date("m/d/Y",strtotime($a->timein)); 
                                ?>
                            <?php endif; ?>
                            <input type="hidden" name="timein_date" value="<?php if(isset($t_in_date)): ?><?php echo e($t_in_date); ?><?php endif; ?>">
                            <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timein" value="<?php if(isset($t_in)): ?><?php echo e($t_in); ?><?php endif; ?>"/>
                        </div>
                    <?php else: ?>
                        <div class="two fields">
                            <div class="field">
                                <label for="">Time In</label>
                                <?php if(isset($a->timein)): ?> 
                                    <?php 
                                        $t_in = date("h:i:s A",strtotime($a->timein)); 
                                        $t_in_date = date("m/d/Y",strtotime($a->timein)); 
                                    ?>
                                <?php endif; ?>
                                <input type="hidden" name="timein_date" value="<?php if(isset($t_in_date)): ?><?php echo e($t_in_date); ?><?php endif; ?>">
                                <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timein" value="<?php if(isset($t_in)): ?><?php echo e($t_in); ?><?php endif; ?>"/>
                            </div>
                            <div class="field">
                                <label for="">Time In Date</label>
                                <input class="readonly" type="text" placeholder="Date" name="date" value="<?php if(isset($a->date)): ?><?php echo e($a->date); ?><?php endif; ?>" readonly="" />
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($a->timeout != null): ?>
                        <div class="field">
                            <label for="">Time Out</label>
                                <?php 
                                    $t_out = date("h:i:s A",strtotime($a->timeout)); 
                                    $t_out_date = date("m/d/Y",strtotime($a->timeout)); 
                                ?>
                            <input type="hidden" name="timeout_date" value="<?php if($a->timeout != null): ?><?php echo e($t_out_date); ?><?php endif; ?>">
                            <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timeout" value="<?php if($a->timeout != null): ?><?php echo e($t_out); ?><?php endif; ?>"/>
                        </div>
                    <?php else: ?>
                        <div class="two fields">
                            <div class="field">
                                <label for="">Time Out</label>
                                <?php if(isset($a->timeout)): ?> 
                                    <?php 
                                        $t_out = date("h:i:s A",strtotime($a->timeout)); 
                                        $t_out_date = date("m/d/Y",strtotime($a->timeout)); 
                                    ?>
                                <?php endif; ?>
                                <input type="hidden" name="timeout_date" value="<?php if($a->timeout != null): ?><?php echo e($t_out_date); ?><?php endif; ?>">
                                <input class="jtimepicker" type="text" placeholder="00:00:00 AM" name="timeout" value="<?php if($a->timeout != null): ?><?php echo e($t_out); ?><?php endif; ?>"/>
                            </div>
                            <div class="field">
                                <label for="">Time Out Date</label>
                                <input type="text" name="timeout_date" value="" class="airdatepicker">
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="fields">
                        <div class="sixteen wide field">
                            <label>Reason</label>
                            <textarea class="" rows="5" name="reason"><?php if(isset($a->reason)): ?><?php echo e($a->reason); ?><?php endif; ?></textarea>
                        </div>
                    </div>
                    
                </div>
                
                <div class="box-footer">
                    <input type="hidden" name="id" value="<?php if(isset($a->id)): ?><?php echo e($a->id); ?><?php endif; ?>">
                    <input type="hidden" name="idno" value="<?php if(isset($a->idno)): ?><?php echo e($a->idno); ?><?php endif; ?>">
                    <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> Update</button>
                    <a class="ui grey small button" href="<?php echo e(url('attendance')); ?>"><i class="ui times icon"></i> Cancel</a>
                </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>

    <script type="text/javascript">
    $('.jtimepicker').mdtimepicker({format:'h:mm:ss tt', theme: 'blue', hourPadding: true});
    $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>