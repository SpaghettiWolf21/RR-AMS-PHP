<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/layouts/clock.blade.php */ ?>
<!doctype html>
<!--
* Racing R Attendance Monitoring System
-->
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

        <title>In-Out Clock | Racing R - AMS</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/bootstrap/css/bootstrap.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/clock.css')); ?>">
        
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="<?php echo e(asset('/assets/js/html5shiv.js')); ?>></script>
            <script src="<?php echo e(asset('/assets/js/respond.min.js')); ?>"></script>
        <![endif]-->

        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body>

    <img src="<?php echo e(asset('/assets/images/img/bg.jpg')); ?>" class="wave">
    <div class="wrapper">
        
        <div id="body">

            <div class="content">

                <?php echo $__env->yieldContent('content'); ?>
             
            </div>

        </div>
    </div>

    <script src="<?php echo e(asset('/assets/vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/script.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html>