<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/reports/report-employee-birthdays.blade.php */ ?>
    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title">Employee Birthdays
                <a href="<?php echo e(url('export/report/birthdays')); ?>" class="ui basic button mini offsettop5 btn-export float-right"><i class="ui icon download"></i>Export to CSV</a>
                <a href="<?php echo e(url('reports')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i>Return</a>
            </h2>   
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>ID #</th>
                                <th>Employee Name</th>
                                <th>Department</th>
                                <th>Position</th>
                                <th>Birthday</th>
                                <th>Contact #</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($empBday)): ?>
                            <?php $__currentLoopData = $empBday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($v->idno); ?></td>
                                    <td><?php echo e($v->lastname); ?>, <?php echo e($v->firstname); ?> <?php echo e($v->mi); ?></td>
                                    <td><?php echo e($v->department); ?></td>
                                    <td><?php echo e($v->jobposition); ?></td>
                                    <td>
                                    <?php $bdaydate = date("D, M d Y", strtotime($v->birthday)); ?>
                                    <?php if($v->birthday != null): ?>
                                        <?php echo e($bdaydate); ?>

                                    <?php endif; ?>
                                    </td>
                                    <td><?php echo e($v->mobileno); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,});
    });
    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>