<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/personal/edits/personal-profile-edit.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title">Edit Profile
                    <a href="<?php echo e(url('personal/profile/view')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i>Return</a>
                </h2>
            </div>    
        </div>

        <div class="row">
            <form id="edit_personal_info_form" action="<?php echo e(url('personal/profile/update')); ?>" class="ui form custom" method="post" accept-charset="utf-8">
            <?php echo e(csrf_field()); ?>


                <div class="col-md-12 float-left">
                    <div class="box box-success">
                        <div class="box-header with-border">Personal Infomation</div>
                        <div class="box-body">
                            <div class="two fields">
                                <div class="field">
                                    <label>First Name</label>
                                    <input type="text" class="uppercase" name="firstname" value="<?php if(isset($person_details->firstname)): ?><?php echo e($person_details->firstname); ?><?php endif; ?>">
                                </div>
                                <div class="field">
                                    <label>Middle Name</label>
                                    <input type="text" class="uppercase" name="mi" value="<?php if(isset($person_details->mi)): ?><?php echo e($person_details->mi); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="field">
                                <label>Last Name</label>
                                <input type="text" class="uppercase" name="lastname" value="<?php if(isset($person_details->lastname)): ?><?php echo e($person_details->lastname); ?><?php endif; ?>">
                            </div>
                            <div class="field">
                                <label>Gender</label>
                                <select name="gender" class="ui dropdown uppercase">
                                    <option value="">Select Gender</option>
                                    <option value="MALE" <?php if(isset($person_details->gender)): ?> <?php if($person_details->gender == 'MALE'): ?> selected <?php endif; ?> <?php endif; ?>>MALE</option>
                                    <option value="FEMALE" <?php if(isset($person_details->gender)): ?> <?php if($person_details->gender == 'FEMALE'): ?> selected <?php endif; ?> <?php endif; ?>>FEMALE</option>
                                </select>
                            </div>
                            <div class="field">
                                <label>Civil Status</label>
                                <select name="civilstatus" class="ui dropdown uppercase">
                                    <option value="">Select Civil Status</option>
                                    <option value="SINGLE" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'SINGLE'): ?> selected <?php endif; ?> <?php endif; ?>>SINGLE</option>
                                    <option value="MARRIED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'MARRIED'): ?> selected <?php endif; ?> <?php endif; ?>>MARRIED</option>
                                    <option value="ANULLED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'ANULLED'): ?> selected <?php endif; ?> <?php endif; ?>>ANULLED</option>
                                    <option value="WIDOWED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'WIDOWED'): ?> selected <?php endif; ?> <?php endif; ?>>WIDOWED</option>
                                    <option value="LEGALLY SEPARATED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'LEGALLY SEPARATED'): ?> selected <?php endif; ?> <?php endif; ?>>LEGALLY SEPARATED</option>
                                </select>
                            </div>

                            <div class="two fields">
                                <div class="field">
                                    <label>Height <span class="help">(cm)</span></label>
                                    <input type="text" name="height" value="<?php if(isset($person_details->height)): ?><?php echo e($person_details->height); ?><?php endif; ?>" placeholder="000">
                                </div>
                                <div class="field">
                                    <label>Weight <span class="help">(pounds)</span></label>
                                    <input type="text" name="weight" value="<?php if(isset($person_details->weight)): ?><?php echo e($person_details->weight); ?><?php endif; ?>" placeholder="000">
                                </div>
                            </div>
                            
                            <div class="two fields">
                            <div class="field">
                                <label>Email Address (Personal)</label>
                                <input type="email" name="emailaddress" value="<?php if(isset($person_details->emailaddress)): ?><?php echo e($person_details->emailaddress); ?><?php endif; ?>"  class="lowercase">
                            </div>
                            <div class="field">
                                <label>Mobile Number</label>
                                <input type="text" class="uppercase" name="mobileno" value="<?php if(isset($person_details->mobileno)): ?><?php echo e($person_details->mobileno); ?><?php endif; ?>">
                            </div>
                            </div>
                            <div class="two fields">
                            <div class="field">
                                <label>Age</label>
                                <input type="text" name="age" value="<?php if(isset($person_details->age)): ?><?php echo e($person_details->age); ?><?php endif; ?>" placeholder="00">
                            </div>
                            <div class="field">
                                <label>Date of Birth</label>
                                <input type="text" name="birthday" value="<?php if(isset($person_details->birthday)): ?><?php echo e($person_details->birthday); ?><?php endif; ?>" class="airdatepicker" placeholder="Date">
                            </div>
                            </div>
                            <div class="field">
                                <label>Place of Birth</label>
                                <input type="text" class="uppercase" name="birthplace" value="<?php if(isset($person_details->birthplace)): ?><?php echo e($person_details->birthplace); ?><?php endif; ?>" placeholder="City, Province, Country">
                            </div>
                            <div class="field">
                                <label>Home Address</label>
                                <input type="text" class="uppercase" name="homeaddress" value="<?php if(isset($person_details->homeaddress)): ?><?php echo e($person_details->homeaddress); ?><?php endif; ?>" placeholder="House/Unit Number, Building, Street, City, Province, Country">
                            </div>
                            <div class="field">
                                <div class="ui error message">
                                <i class="close icon"></i>
                                    <div class="header"></div>
                                    <ul class="list">
                                        <li class=""></li>
                                    </ul>
                                </div>
                            </div>
                            <br>
                            
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12 float-left">
                    <div class="action align-right">
                        <button type="submit" name="submit" class="ui green button small"><i class="ui checkmark icon"></i> Update</button>
                        <a href="<?php echo e(url('personal/dashboard')); ?>" class="ui grey small button cancel"><i class="ui times icon"></i> Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>
    <script type="text/javascript">
        $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>