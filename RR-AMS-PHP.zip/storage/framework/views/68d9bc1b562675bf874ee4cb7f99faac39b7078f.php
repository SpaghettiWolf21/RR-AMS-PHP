<?php /* C:\Users\buyan\Documents\Github\RR-AMS-PHP\resources\views/admin/dashboard.blade.php */ ?>
    
    <?php $__env->startSection('styles'); ?>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <h2 class="page-title">Dashboard</h2>
            </div>    
        </div>

        <div class="row">

            <div class="col-md-4">
                <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="ui icon user circle"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">EMPLOYEES</span>
                        <div class="progress-group">
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-aqua" style="width: 100%"></div>
                            </div>
                            <div class="stats_d">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td>Regular</td>
                                            <td><?php if(isset($emp_typeR)): ?> <?php echo e($emp_typeR); ?> <?php endif; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Trainee</td>
                                            <td><?php if(isset($emp_typeT)): ?> <?php echo e($emp_typeT); ?> <?php endif; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="ui icon clock outline"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">ATTENDANCES</span>
                        <div class="progress-group">
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-green" style="width: 100%"></div>
                            </div>
                            <div class="stats_d">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td>Online</td>
                                            <td><?php if(isset($is_online_now)): ?> <?php echo e($is_online_now); ?> <?php endif; ?></td> <!--May problem ditu-->
                                        </tr>
                                        <tr>
                                            <td>Offline</td>
                                            <td><?php if(isset($is_offline_now)): ?> <?php echo e($is_offline_now); ?> <?php endif; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="info-box">
                    <span class="info-box-icon bg-orange"><i class="ui icon home"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">LEAVES OF ABSENCE</span>
                        <div class="progress-group">
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-orange" style="width: 100%"></div>
                            </div>
                            <div class="stats_d">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td>Approved</td>
                                            <td><?php if(isset($emp_leaves_approve)): ?> <?php echo e($emp_leaves_approve); ?> <?php endif; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Pending</td>
                                            <td><?php if(isset($emp_leaves_pending)): ?> <?php echo e($emp_leaves_pending); ?> <?php endif; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-md-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Newest Employees</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                    <table class="table responsive nobordertop">
                        <thead>
                            <tr>
                                <th class="text-left">Name</th>
                                <th class="text-left">Position</th>
                                <th class="text-left">Start Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($emp_all_type)): ?>
                                <?php $__currentLoopData = $emp_all_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-left name-title"><?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?></td>
                                    <td class="text-left"><?php echo e($data->jobposition); ?></td>
                                    <td class="text-left"><?php echo e(date('M d, Y', strtotime($data->startdate))) ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Recent Attendances</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                        <table class="table responsive nobordertop">
                        <thead>
                            <tr>
                                <th class="text-left">Name</th>
                                <th class="text-left">Type</th>
                                <th class="text-left">Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($a)): ?>
                            <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                            <?php if($v->timein != null && $v->timeout == null): ?>
                            <tr>
                                <td class="name-title"><?php echo e($v->employee); ?></td>
                                <td>Time-In</td>
                                <td><?php echo e(date('h:i:s A', strtotime($v->timein))) ?></td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if($v->timein != null && $v->timeout != null): ?>
                            <tr>
                                <td class="name-title"><?php echo e($v->employee); ?></td>
                                <td>Time-Out</td>
                                <td><?php echo e(date('h:i:s A', strtotime($v->timeout))) ?></td>
                            </tr>
                            <?php endif; ?>

                            <?php if($v->timein != null && $v->timeout != null): ?>
                            <tr>
                                <td class="name-title"><?php echo e($v->employee); ?></td>
                                <td>Time-In</td>
                                <td><?php echo e(date('h:i:s A', strtotime($v->timein))) ?></td>
                            </tr>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        
            <div class="col-md-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Recent Leaves of Absence</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                    <table class="table responsive nobordertop">
                        <thead>
                            <tr>
                                <th class="text-left">Name</th>
                                <th class="text-left">Date</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php if(isset($emp_approved_leave)): ?>
                                <?php $__currentLoopData = $emp_approved_leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-left name-title"><?php echo e($leaves->employee); ?></td>
                                    <td class="text-left"><?php echo e(date('M d, Y', strtotime($leaves->leavefrom))) ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                    </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>